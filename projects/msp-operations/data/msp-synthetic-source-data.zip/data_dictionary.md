# MSP Turnaround Portfolio Project — Source Data Dictionary

## 1. File formats and reporting dates

| Convention | Specification |
| :--- | :--- |
| **Character Encoding** | UTF-8 without Byte Order Mark (`UTF8Encoding($false)`) |
| **Line Endings & Delimiters** | LF (`\n`), comma-delimited (`,`), RFC 4180 minimal double-quote escaping |
| **Calendar Dates** | ISO-8601 `yyyy-MM-dd` (e.g., `2025-02-28`) |
| **Service / Snapshot Months** | ISO-8601 `yyyy-MM` (e.g., `2025-02`) |
| **Timestamps (UTC)** | ISO-8601 UTC `yyyy-MM-ddTHH:mm:ssZ` (e.g., `2026-11-01T00:00:00Z`) |
| **Decimal Formatting** | Invariant culture (`InvariantCulture`), two fixed decimal places (`0.00`), no currency symbols or thousands separators |
| **Boolean Flags** | Integer strings `1` (true) and `0` (false) for direct SQL `BIT` / `INT` ingestion |
| **Null Representation** | Empty string (`""`, rendered as adjacent commas `,` in CSV) |
| **Simulation Window** | `2024-11-01T00:00:00Z` through `2026-10-31T23:59:59Z` (24 complete calendar months) |
| **Reporting Cutoffs** | Batch 1 cutoff: `2026-10-01T00:00:00Z`; Batch 2 / Final reporting cutoff: `2026-11-01T00:00:00Z` |

## 2. Source File Inventory & Grain Summary

| CSV File Name | Row Grain (What One Row Represents) | Primary Key | Foreign Keys | Row Count |
| :--- | :--- | :--- | :--- | ---: |
| `clients.csv` | One client account with industry and lifecycle dates | `ClientId` | None | 18 |
| `staff_rates.csv` | One employee and effective pay rate with role, department, and burden multiplier | `StaffId` | None | 14 |
| `agreements.csv` | One managed-services agreement term with workstation rate, tool cost, renewal date, and 60-day notice deadline | `AgreementId` | `ClientId` | 21 |
| `device_snapshots.csv` | One managed or excluded client device at a calendar month-end snapshot | `SnapshotId` | `ClientId`, `AgreementId` | 33,129 |
| `tickets_batch_01.csv` | One exported service-desk ticket version in the October 1, 2026 export (`BatchNumber = 1`) | `ExportRowId` | `ClientId`, `AgreementId`, `DeviceId`, `AssignedStaffId`, `ClosedByStaffId` | 27,400 |
| `tickets_batch_02.csv` | One exported service-desk ticket version in the November 1, 2026 export (`BatchNumber = 2`: new October tickets, late updates, and repeated ticket records with new export row IDs) | `ExportRowId` | `ClientId`, `AgreementId`, `DeviceId`, `AssignedStaffId`, `ClosedByStaffId` | 1,469 |
| `time_entries.csv` | One logged labor entry by a staff member on a date (ticket work, proactive agreement work, or project engineering) | `TimeEntryId` | `StaffId`, `ClientId`, `TicketId`, `AgreementId`, `ProjectId` | 29,987 |
| `invoice_lines.csv` | One issued billing line for a recurring managed agreement or fixed-fee project | `InvoiceLineId` | `ClientId`, `AgreementId`, `ProjectId` | 433 |
| `staff_payroll.csv` | One employee per paid calendar month with paid hours and loaded payroll cost | `PayrollRowId` | `StaffId` | 336 |
| `projects.csv` | One fixed-fee client project with schedule dates and contract value | `ProjectId` | `ClientId` | 24 |
| `contractor_work_orders.csv` | One subcontractor work order linked to a project and approval status | `WorkOrderId` | `ProjectId`, `ClientId` | 26 |
| `monthly_overhead.csv` | One calendar month of non-delivery operating overhead costs by expense category | `OverheadMonth` | None | 24 |
| `sla_policy.csv` | One elapsed-time SLA policy target per ticket priority level | `Priority` | None | 4 |
| `surveys.csv` | One post-closure CSAT survey invitation per surveyed ticket with optional response and 1–5 score | `SurveyId` | `TicketId`, `ClientId` | 11,028 |

## 3. Detailed Table Schemas

### 3.1 `clients.csv`
One row per fictional U.S. SMB client (`18` rows).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `ClientId` | `VARCHAR(16)` | PK, Not Null | `CLI-001`..`CLI-018` | Stable client identifier |
| `ClientName` | `VARCHAR(100)` | Not Null | Text | Fictional client legal/DBA name (e.g., `Everywhere Dentistry`, `Beacon Point Health`) |
| `Industry` | `VARCHAR(60)` | Not Null | Text | Client industry vertical (e.g., `Healthcare - Dental`, `Manufacturing`, `Financial Services`) |
| `OnboardingDate` | `DATE` | Not Null | `yyyy-MM-dd` | Date client agreement coverage began (`CLI-016` onboards `2025-04-01`; `CLI-017` onboards `2025-09-01`) |
| `DepartureDate` | `DATE` | Nullable (`""`) | `yyyy-MM-dd` | Date client departed at contract expiration (`2026-02-28` for `CLI-018`; empty string `""` for active clients) |
| `AccountStatus` | `VARCHAR(20)` | Not Null | Enum | Allowed values: `Active`, `Departed` |
| `BillingArchetype` | `VARCHAR(160)` | Not Null | Text | Simulation documentation note describing the client's contract/margin archetype |

### 3.2 `staff_rates.csv`
One row per employee (`14` rows across `Service Delivery` and `Project Engineering`).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `StaffId` | `VARCHAR(16)` | PK, Not Null | `STF-101`..`STF-502` | Stable employee identifier (`101..104` Tier 1, `201..204` Tier 2, `301..303` Sysadmin, `401` Manager, `501..502` Project Eng) |
| `FullName` | `VARCHAR(80)` | Not Null | Text | Employee full name (includes `Marcus Vance` `STF-101` and `Liam Gallagher` `STF-201`) |
| `Role` | `VARCHAR(50)` | Not Null | Enum | Allowed values: `Tier 1 Support Technician`, `Tier 2 Support Technician`, `Systems Administrator`, `Service Desk Manager`, `Project Engineer` |
| `Department` | `VARCHAR(40)` | Not Null | Enum | Allowed values: `Service Delivery` (12 staff, including Service Desk Manager), `Project Engineering` (2 staff) |
| `EffectiveStartDate` | `DATE` | Not Null | `yyyy-MM-dd` | Rate effective start date |
| `EffectiveEndDate` | `DATE` | Not Null | `yyyy-MM-dd` | Rate effective end date (`2026-12-31`) |
| `BaseHourlyRate` | `DECIMAL(10,2)` | Not Null | USD / Hour (`0.00`) | Base hourly pay rate (`19.00`, `23.00`, `30.00`, or `40.00`) |
| `EmployerCostMultiplier` | `DECIMAL(5,2)` | Not Null | Multiplier (`1.30`) | Employer payroll taxes and benefits multiplier (`1.30`) |
| `LoadedHourlyRate` | `DECIMAL(10,2)` | Not Null | USD / Hour (`0.00`) | `BaseHourlyRate * EmployerCostMultiplier` (`24.70`, `29.90`, `39.00`, or `52.00`) |

### 3.3 `agreements.csv`
One row per managed-services agreement term (`21` rows across 18 clients, including two 2-term renewals with rate increases and one 2-term auto-renewal at a legacy rate).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `AgreementId` | `VARCHAR(20)` | PK, Not Null | `AGR-XXX-TN` | Stable agreement term identifier (e.g., `AGR-001-T1`, `AGR-002-T1`, `AGR-002-T2`) |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Links to `clients.csv(ClientId)` |
| `AgreementName` | `VARCHAR(120)` | Not Null | Text | Descriptive contract title |
| `TermNumber` | `INT` | Not Null | Integer (`1`, `2`) | Sequential term number for the client |
| `EffectiveStartDate` | `DATE` | Not Null | `yyyy-MM-dd` | Inclusive start date of the agreement term |
| `EffectiveEndDate` | `DATE` | Not Null | `yyyy-MM-dd` | Inclusive end date of the agreement term |
| `SignedRatePerWorkstation` | `DECIMAL(10,2)` | Not Null | USD / Seat / Month | Signed monthly price per eligible workstation (`44.00` to `88.00`; `45.00` for `CLI-001`) |
| `ToolCostPerWorkstation` | `DECIMAL(10,2)` | Not Null | USD / Seat / Month | Direct monthly RMM/EDR/backup tool stack cost per eligible workstation (`10.00` to `12.00`) |
| `RenewalDate` | `DATE` | Not Null | `yyyy-MM-dd` | Next annual renewal date (`EffectiveEndDate + 1 day`) |
| `NoticePeriodDays` | `INT` | Not Null | Days (`60`) | Contractual non-renewal/repricing notice period (`60` calendar days) |
| `NoticeDeadlineDate` | `DATE` | Not Null | `yyyy-MM-dd` | `RenewalDate` minus `60` calendar days |
| `AgreementStatus` | `VARCHAR(24)` | Not Null | Enum | Allowed values: `Active`, `Renewed`, `Auto-Renewed`, `Expired` |

### 3.4 `device_snapshots.csv`
One row per tracked client workstation at a calendar month-end snapshot (`33,129` rows across 24 months).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `SnapshotId` | `VARCHAR(20)` | PK, Not Null | `SNP-XXXXXX` | Stable month-end device snapshot row ID |
| `SnapshotMonth` | `CHAR(7)` | Not Null | `yyyy-MM` | Calendar month of the snapshot (`2024-11` through `2026-10`) |
| `SnapshotDate` | `DATE` | Not Null | `yyyy-MM-dd` | Calendar month-end date (`2024-11-30` through `2026-10-31`) |
| `DeviceId` | `VARCHAR(24)` | Not Null | `DEV-PPP-NNN` | Stable device identifier across months |
| `Hostname` | `VARCHAR(32)` | Not Null | Text | RMM agent hostname |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Links to `clients.csv(ClientId)` |
| `AgreementId` | `VARCHAR(20)` | FK, Not Null | `AGR-XXX-TN` | Links to active agreement in `agreements.csv(AgreementId)` |
| `DeviceType` | `VARCHAR(20)` | Not Null | Enum | Allowed values: `Desktop`, `Laptop` |
| `IsActive` | `BIT` / `INT` | Not Null | `1` or `0` | `1` if agent is active at month-end, `0` if retired/pending decommission |
| `IsBillable` | `BIT` / `INT` | Not Null | `1` or `0` | `1` if eligible managed workstation under the agreement (`IsActive = 1` and not excluded); `0` if excluded |
| `ExclusionReason` | `VARCHAR(50)` | Nullable (`""`) | Enum / Empty | Populated when `IsBillable = 0`: `Spare_In_Closet`, `Lab_Imaging_Test_Unit`, `Conference_Room_Kiosk`, `Contractor_BYOD_Excluded`, `Retired_Pending_Decommission`; empty `""` when `IsBillable = 1` |

### 3.5 `tickets_batch_01.csv` and `tickets_batch_02.csv`
One row per exported ticket version (`27,400` rows in `tickets_batch_01.csv`; `1,469` rows in `tickets_batch_02.csv`). Both files share the exact same 20-column schema.

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `ExportRowId` | `VARCHAR(24)` | PK, Not Null | `EXP-B1-XXXXXX` / `EXP-B2-XXXXXX` | Stable unique export row identifier used for raw ingestion idempotency |
| `BatchNumber` | `INT` | Not Null | `1` or `2` | Export delivery batch number (`1` for Oct 1, 2026 export; `2` for Nov 1, 2026 export) |
| `DeliveryTimestampUtc` | `DATETIME2(0)` | Not Null | ISO UTC (`Z`) | `2026-10-01T00:00:00Z` for Batch 1; `2026-11-01T00:00:00Z` for Batch 2 |
| `TicketId` | `VARCHAR(20)` | Business Key | `TKT-000001`..`TKT-028600` | Stable service-desk ticket identifier across batches |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Links to `clients.csv(ClientId)` |
| `AgreementId` | `VARCHAR(20)` | FK, Not Null | `AGR-XXX-TN` | Links to `agreements.csv(AgreementId)` |
| `DeviceId` | `VARCHAR(24)` | FK, Not Null | `DEV-PPP-NNN` | Links to the affected workstation |
| `IssueCode` | `VARCHAR(24)` | Not Null | Code | Allowed values: `IAM-PASS`, `IAM-MFA`, `END-PROFILE`, `END-PRINT`, `APP-M365`, `NET-VPN`, `NET-WIFI`, `HW-DOCK`, `HW-SCANNER`, `APP-LOB`, `APP-ERP-DB`, `SEC-EDR`, `INFRA-STORAGE`, `INFRA-BACKUP` |
| `IssueCategory` | `VARCHAR(40)` | Not Null | Category | Allowed values: `Identity & Access`, `Endpoint & OS`, `Productivity Apps`, `Network & Connectivity`, `Hardware & Peripherals`, `Line of Business Apps`, `Security & Compliance`, `Server & Cloud Infrastructure` |
| `Priority` | `VARCHAR(20)` | FK, Not Null | Enum | Links to `sla_policy.csv(Priority)`: `P1 - Critical`, `P2 - High`, `P3 - Medium`, `P4 - Low` |
| `Status` | `VARCHAR(24)` | Not Null | Enum | Allowed values: `Open`, `In Progress`, `Waiting on Client`, `Resolved`, `Closed` |
| `CreatedAtUtc` | `DATETIME2(0)` | Not Null | ISO UTC (`Z`) | Ticket creation timestamp in UTC |
| `FirstResponseAtUtc` | `DATETIME2(0)` | Nullable (`""`) | ISO UTC (`Z`) | First technician response timestamp in UTC (empty `""` if `Status = 'Open'`) |
| `ResolvedAtUtc` | `DATETIME2(0)` | Nullable (`""`) | ISO UTC (`Z`) | Technical resolution timestamp in UTC (populated when `Status` is `Resolved` or `Closed`) |
| `ClosedAtUtc` | `DATETIME2(0)` | Nullable (`""`) | ISO UTC (`Z`) | Final qualifying service-desk closure timestamp in UTC (populated **only** when `Status = 'Closed'`) |
| `SourceUpdatedAtUtc` | `DATETIME2(0)` | Not Null | ISO UTC (`Z`) | Last modification timestamp in the source PSA system as of the batch cutoff |
| `AssignedStaffId` | `VARCHAR(16)` | FK, Not Null | `STF-XXX` | Primary assigned technician in `staff_rates.csv(StaffId)` |
| `ClosingActorType` | `VARCHAR(20)` | Nullable (`""`) | Enum / Empty | Allowed values when `Status = 'Closed'`: `Technician`, `Automation`, `Unknown`; empty `""` when not closed |
| `ClosedByStaffId` | `VARCHAR(16)` | FK, Nullable (`""`) | `STF-XXX` / Empty | Populated with closing technician `StaffId` when `ClosingActorType = 'Technician'`; empty `""` otherwise |
| `ClosingActorKey` | `VARCHAR(24)` | Nullable (`""`) | Key / Empty | Dimension join key when `Status = 'Closed'`: `STF-XXX` (technician), `ACTOR-AUTOMATION`, or `ACTOR-UNKNOWN` |

### 3.6 `time_entries.csv`
One row per logged work entry (`29,987` rows).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `TimeEntryId` | `VARCHAR(20)` | PK, Not Null | `TME-XXXXXX` | Stable time entry identifier |
| `StaffId` | `VARCHAR(16)` | FK, Not Null | `STF-XXX` | Staff member logging the work (`staff_rates.csv`) |
| `WorkDate` | `DATE` | Not Null | `yyyy-MM-dd` | Calendar date work was performed (strictly within ticket lifecycle for ticket entries) |
| `WorkMonth` | `CHAR(7)` | Not Null | `yyyy-MM` | Calendar month of `WorkDate` (`2024-11` through `2026-10`) |
| `MinutesLogged` | `INT` | Not Null | Minutes | Duration in integer minutes (`30`, `45`, `60`, `90`, `180`, `300`) |
| `HoursLogged` | `DECIMAL(10,2)` | Not Null | Hours (`0.00`) | `MinutesLogged / 60.0` |
| `LoadedLaborCost` | `DECIMAL(10,2)` | Not Null | USD (`0.00`) | `HoursLogged * LoadedHourlyRate` of `StaffId` |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Client receiving the service |
| `WorkType` | `VARCHAR(20)` | Not Null | Enum | Allowed values: `Ticket` (incident/request), `Proactive` (covered agreement maintenance without a ticket), `Project` (fixed-fee project engineering) |
| `TicketId` | `VARCHAR(20)` | FK, Nullable (`""`) | `TKT-XXXXXX` / Empty | Populated when `WorkType = 'Ticket'`; empty `""` for `Proactive` and `Project` entries |
| `AgreementId` | `VARCHAR(20)` | FK, Nullable (`""`) | `AGR-XXX-TN` / Empty | Populated for `Ticket` and `Proactive` covered agreement work; empty `""` for `Project` work |
| `ProjectId` | `VARCHAR(20)` | FK, Nullable (`""`) | `PRJ-XXX` / Empty | Populated when `WorkType = 'Project'`; empty `""` for `Ticket` and `Proactive` work |
| `IssueCode` | `VARCHAR(24)` | Not Null | Code | Issue code from ticket, `INFRA-BACKUP` for proactive maintenance, or `PRJ-ENG` for project work |
| `Notes` | `VARCHAR(160)` | Not Null | Text | Brief work description |

### 3.7 `invoice_lines.csv`
One row per issued client billing line (`433` rows: `409` recurring managed agreement lines + `24` fixed-fee project lines).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `InvoiceLineId` | `VARCHAR(20)` | PK, Not Null | `INV-L-XXXX` | Stable invoice line identifier |
| `InvoiceId` | `VARCHAR(24)` | Not Null | `INV-YYYYMM-XXX` | Parent invoice identifier |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Billed client (`clients.csv`) |
| `ServiceMonth` | `CHAR(7)` | Not Null | `yyyy-MM` | Service period month (`2024-11` through `2026-10`) |
| `InvoiceDate` | `DATE` | Not Null | `yyyy-MM-dd` | Date invoice was issued |
| `LineType` | `VARCHAR(24)` | Not Null | Enum | Allowed values: `Managed_Agreement`, `Project_Fixed_Fee` |
| `AgreementId` | `VARCHAR(20)` | FK, Nullable (`""`) | `AGR-XXX-TN` / Empty | Populated when `LineType = 'Managed_Agreement'`; empty `""` for projects |
| `ProjectId` | `VARCHAR(20)` | FK, Nullable (`""`) | `PRJ-XXX` / Empty | Populated when `LineType = 'Project_Fixed_Fee'`; empty `""` for managed agreements |
| `Description` | `VARCHAR(160)` | Not Null | Text | Line item description |
| `BilledQuantity` | `INT` | Not Null | Integer | Billed workstations (for `Managed_Agreement`) or `1` (for `Project_Fixed_Fee`) |
| `UnitRate` | `DECIMAL(10,2)` | Not Null | USD (`0.00`) | Billed unit price (matches signed agreement rate or project contract amount) |
| `LineAmount` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | `BilledQuantity * UnitRate` |
| `InvoiceStatus` | `VARCHAR(20)` | Not Null | Enum | Allowed values: `Paid`, `Issued` |

### 3.8 `staff_payroll.csv`
One row per employee per paid month (`336` rows = 14 staff × 24 months).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `PayrollRowId` | `VARCHAR(16)` | PK, Not Null | `PAY-XXXX` | Stable payroll ledger row ID |
| `PayrollMonth` | `CHAR(7)` | Not Null | `yyyy-MM` | Paid calendar month (`2024-11` through `2026-10`) |
| `StaffId` | `VARCHAR(16)` | FK, Not Null | `STF-XXX` | Employee ID (`staff_rates.csv`) |
| `Department` | `VARCHAR(40)` | Not Null | Enum | `Service Delivery` or `Project Engineering` |
| `Role` | `VARCHAR(50)` | Not Null | Text | Employee role title |
| `PaidHours` | `DECIMAL(10,2)` | Not Null | Hours (`0.00`) | Calendar-based monthly paid hours (`152.00`, `160.00`, `168.00`, `176.00`, or `184.00`) |
| `BaseHourlyRate` | `DECIMAL(10,2)` | Not Null | USD / Hour | Employee base hourly pay rate |
| `LoadedHourlyRate` | `DECIMAL(10,2)` | Not Null | USD / Hour | Employee loaded hourly rate (`BaseHourlyRate * 1.30`) |
| `BasePayrollCost` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | `PaidHours * BaseHourlyRate` |
| `EmployerBurdenCost` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | `LoadedPayrollCost - BasePayrollCost` |
| `LoadedPayrollCost` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | `PaidHours * LoadedHourlyRate` |

### 3.9 `projects.csv`
One row per client engineering project (`24` rows, one per calendar month `PRJ-198` through `PRJ-221`, including hand-checkable rollout project `PRJ-201`).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `ProjectId` | `VARCHAR(16)` | PK, Not Null | `PRJ-198`..`PRJ-221` | Stable project identifier |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Client sponsoring the project |
| `ProjectName` | `VARCHAR(120)` | Not Null | Text | Descriptive project name |
| `ProjectType` | `VARCHAR(40)` | Not Null | Enum | Allowed values: `Workstation Rollout`, `Network Upgrade`, `Infrastructure`, `Onboarding`, `Security & Compliance`, `Cloud Migration` |
| `StartDate` | `DATE` | Not Null | `yyyy-MM-dd` | Project start date |
| `CompletionDate` | `DATE` | Not Null | `yyyy-MM-dd` | Project completion/billing date |
| `ServiceMonth` | `CHAR(7)` | Not Null | `yyyy-MM` | Primary delivery and billing month |
| `ProjectStatus` | `VARCHAR(20)` | Not Null | Enum | Allowed values: `Completed` |
| `ContractAmount` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Fixed-fee contract amount |

### 3.10 `contractor_work_orders.csv`
One row per subcontractor work order (`26` rows: `24` `Approved`, `1` `Rejected`, `1` `Pending_Approval`).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `WorkOrderId` | `VARCHAR(16)` | PK, Not Null | `CWO-001`..`CWO-026` | Stable contractor work order ID |
| `ProjectId` | `VARCHAR(16)` | FK, Not Null | `PRJ-XXX` | Links to `projects.csv(ProjectId)` |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Links to `clients.csv(ClientId)` |
| `VendorName` | `VARCHAR(80)` | Not Null | Text | Subcontractor vendor name |
| `WorkOrderDate` | `DATE` | Not Null | `yyyy-MM-dd` | Work order date |
| `ServiceMonth` | `CHAR(7)` | Not Null | `yyyy-MM` | Service month (`2024-11` through `2026-10`) |
| `Description` | `VARCHAR(160)` | Not Null | Text | Subcontracted scope description |
| `WorkOrderStatus` | `VARCHAR(24)` | Not Null | Enum | Allowed values: `Approved` (include in project COGS), `Rejected` (exclude), `Pending_Approval` (exclude) |
| `Amount` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Work order dollar amount |

### 3.11 `monthly_overhead.csv`
One row per calendar month of non-delivery operating expenses (`24` rows).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `OverheadMonth` | `CHAR(7)` | PK, Not Null | `yyyy-MM` | Calendar month (`2024-11` through `2026-10`) |
| `MonthStartDate` | `DATE` | Not Null | `yyyy-MM-dd` | First day of the calendar month |
| `FacilitiesAndRent` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Office lease and utilities (`8500.00`/month) |
| `CoreInternalSoftware` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Internal PSA, accounting, and corporate licensing (`5200.00`/month) |
| `SalesAndMarketing` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Lead generation and account management overhead (`3300.00` to `3600.00`/month) |
| `GeneralAndAdmin` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Administrative salaries, bookkeeping, and office expenses (`4800.00` to `5100.00`/month) |
| `InsuranceAndLegal` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | E&O/cyber insurance and legal retainer (`2100.00` in Year 1; `2250.00` in Year 2) |
| `TotalOverheadCost` | `DECIMAL(12,2)` | Not Null | USD (`0.00`) | Sum of the five overhead categories (`24000.00` in Jan/Feb 2025; `24000.00` to `24650.00` across 24 months) |
| `AssumptionNotes` | `VARCHAR(200)` | Not Null | Text | Documented overhead simulation assumption |

### 3.12 `sla_policy.csv`
One row per ticket priority level (`4` rows).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `Priority` | `VARCHAR(20)` | PK, Not Null | Enum | `P1 - Critical`, `P2 - High`, `P3 - Medium`, `P4 - Low` |
| `PriorityRank` | `INT` | Not Null | `1`..`4` | Numeric sort order (`1` = highest urgency) |
| `FirstResponseTargetMinutes` | `INT` | Not Null | Minutes | Elapsed target minutes to `FirstResponseAtUtc` (`15`, `60`, `240`, `480`) |
| `ResolutionTargetMinutes` | `INT` | Not Null | Minutes | Elapsed target minutes to `ResolvedAtUtc` (`240`, `480`, `1440`, `4320`) |
| `ResponseTargetHours` | `DECIMAL(6,2)` | Not Null | Hours (`0.00`) | Target response time in hours (`0.25`, `1.00`, `4.00`, `8.00`) |
| `ResolutionTargetHours` | `DECIMAL(6,2)` | Not Null | Hours (`0.00`) | Target resolution time in hours (`4.00`, `8.00`, `24.00`, `72.00`) |
| `MeasurementBasis` | `VARCHAR(40)` | Not Null | Constant | `Elapsed_24x7_Minutes` |

### 3.13 `surveys.csv`
One row per post-closure survey invitation (`11,028` rows).

| Column Name | Fabric / SQL Type | Key / Null | Units / Format | Description & Allowed Values |
| :--- | :--- | :--- | :--- | :--- |
| `SurveyId` | `VARCHAR(20)` | PK, Not Null | `SRV-XXXXXX` | Stable survey invitation ID |
| `TicketId` | `VARCHAR(20)` | FK, Unique | `TKT-XXXXXX` | Links to closed ticket (`TicketId`) |
| `ClientId` | `VARCHAR(16)` | FK, Not Null | `CLI-XXX` | Links to `clients.csv(ClientId)` |
| `InvitedAtUtc` | `DATETIME2(0)` | Not Null | ISO UTC (`Z`) | Timestamp when survey invitation was sent after closure |
| `RespondedAtUtc` | `DATETIME2(0)` | Nullable (`""`) | ISO UTC (`Z`) | Timestamp when client submitted response (empty `""` when `IsResponded = 0`) |
| `IsResponded` | `BIT` / `INT` | Not Null | `1` or `0` | `1` if survey response received; `0` if no response |
| `CsatScore` | `INT` | Nullable (`""`) | Integer `1`..`5` | Integer satisfaction score `1` (lowest) to `5` (highest) when `IsResponded = 1`; empty `""` when `IsResponded = 0` |
| `FeedbackCategory` | `VARCHAR(40)` | Nullable (`""`) | Enum / Empty | Allowed values when `IsResponded = 1`: `Fast Resolution`, `Helpful Technician`, `Clear Communication`, `Slow Initial Response`, `Repeat Issue Frustration` |
